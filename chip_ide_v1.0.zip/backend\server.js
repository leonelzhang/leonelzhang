const express = require('express');
const cors = require('cors');
const path = require('path');
const { modules, generateTopModuleCode } = require('./modules');

const app = express();
const PORT = 3000;

// 中间件
app.use(cors());
app.use(express.json());

// 提供静态文件服务
app.use(express.static(path.join(__dirname, '../frontend')));

// API接口：获取模块列表
app.get('/api/modules', (req, res) => {
    res.json(modules);
});

// API接口：生成Verilog代码
app.post('/api/generate-code', (req, res) => {
    try {
        const design = req.body;
        const code = generateTopModuleCode(design);
        res.json({ code });
    } catch (error) {
        res.status(500).json({ error: '生成代码失败' });
    }
});

// 启动服务器
app.listen(PORT, () => {
    console.log(`服务器运行在 http://localhost:${PORT}`);
});
