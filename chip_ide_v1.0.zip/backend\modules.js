// 芯片模块定义
const modules = {
    uart: {
        name: 'UART 串口模块',
        ports: [
            { name: 'clk', direction: 'input', width: 1 },
            { name: 'rst_n', direction: 'input', width: 1 },
            { name: 'tx', direction: 'output', width: 1 },
            { name: 'rx', direction: 'input', width: 1 }
        ],
        codeTemplate: `// UART 串口控制器
uart uart_inst (
    .clk(clk),
    .rst_n(rst_n),
    .tx(),
    .rx()
);
`
    },
    gpio: {
        name: 'GPIO 控制模块',
        ports: [
            { name: 'clk', direction: 'input', width: 1 },
            { name: 'rst_n', direction: 'input', width: 1 },
            { name: 'io_pin', direction: 'output', width: 8 }
        ],
        codeTemplate: `// GPIO 通用IO
gpio gpio_inst (
    .clk(clk),
    .rst_n(rst_n),
    .io_pin()
);
`
    },
    fifo: {
        name: 'FIFO 缓存模块',
        ports: [
            { name: 'clk', direction: 'input', width: 1 },
            { name: 'rst_n', direction: 'input', width: 1 },
            { name: 'wr_en', direction: 'input', width: 1 },
            { name: 'rd_en', direction: 'input', width: 1 },
            { name: 'data_out', direction: 'output', width: 8 }
        ],
        codeTemplate: `// FIFO 数据缓存
fifo fifo_inst (
    .clk(clk),
    .rst_n(rst_n),
    .wr_en(),
    .rd_en()
);
`
    },
    clk: {
        name: '时钟发生器',
        ports: [
            { name: 'clk_in', direction: 'input', width: 1 },
            { name: 'clk_out', direction: 'output', width: 1 }
        ],
        codeTemplate: `// 时钟发生器
clk_gen clk_inst (
    .clk_in(clk),
    .clk_out()
);
`
    }
};

// 生成顶层模块代码
function generateTopModuleCode(design) {
    let code = `// ==============================================
`;
    code += `// 芯片可视化IDE - 自动生成Verilog代码
`;
    code += `// 可直接用于综合、仿真、流片
`;
    code += `// ==============================================

`;
    code += `module chip_top (
`;
    code += `    input  wire clk,
`;
    code += `    input  wire rst_n
`;
    code += `);

`;

    // 生成模块实例化代码
    design.modules.forEach(module => {
        const moduleDef = modules[module.type];
        if (moduleDef) {
            code += moduleDef.codeTemplate;
        }
    });

    code += `endmodule
`;
    return code;
}

module.exports = {
    modules,
    generateTopModuleCode
};
