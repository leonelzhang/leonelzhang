const canvas = document.getElementById('canvas');
const rtlCode = document.getElementById('rtlCode');
const exportBtn = document.getElementById('exportBtn');
const saveBtn = document.getElementById('saveBtn');
const loadBtn = document.getElementById('loadBtn');

let placedModules = [];
let connections = [];
let nextModuleId = 1;
let draggingModule = null;
let currentConnection = null;
let currentDragData = null;

// 1. 拖拽元件
document.querySelectorAll('.module-item').forEach(item => {
    item.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('type', e.target.dataset.type);
        e.dataTransfer.setData('name', e.target.innerText);
    });
});

// 2. 放置到画布
canvas.addEventListener('dragover', (e) => e.preventDefault());
canvas.addEventListener('drop', (e) => {
    e.preventDefault();
    const type = e.dataTransfer.getData('type');
    const name = e.dataTransfer.getData('name');
    
    // 创建模块节点
    const div = document.createElement('div');
    div.className = 'drag-module';
    div.innerText = name;
    div.style.left = e.offsetX + 'px';
    div.style.top = e.offsetY + 'px';
    div.dataset.id = nextModuleId;
    div.dataset.type = type;
    canvas.appendChild(div);

    // 添加端口
    addPorts(div, type);

    // 保存并生成代码
    placedModules.push({
        id: nextModuleId,
        type: type,
        name: name,
        x: e.offsetX,
        y: e.offsetY
    });
    nextModuleId++;
    refreshRTL();
    enableDrag(div);
});

// 3. 画布模块可拖动
function enableDrag(el) {
    el.addEventListener('mousedown', (e) => {
        // 如果点击的是端口或端口标签，不触发拖拽
        if (e.target.classList.contains('module-port') || e.target.classList.contains('port-label')) {
            return;
        }
        
        // 设置当前拖拽数据
        currentDragData = {
            element: el,
            offsetX: e.clientX - el.offsetLeft,
            offsetY: e.clientY - el.offsetTop,
            moduleId: parseInt(el.dataset.id)
        };
    });
}

// 全局鼠标移动事件处理
function handleGlobalMouseMove(e) {
    if (!currentDragData) return;
    
    const { element, offsetX, offsetY, moduleId } = currentDragData;
    const newX = e.clientX - offsetX;
    const newY = e.clientY - offsetY;
    
    // 更新元素位置
    element.style.left = newX + 'px';
    element.style.top = newY + 'px';
    
    // 更新模块位置
    const module = placedModules.find(m => m.id === moduleId);
    if (module) {
        module.x = newX;
        module.y = newY;
    }
    
    // 更新连接线条
    updateConnections();
}

// 全局鼠标释放事件处理
function handleGlobalMouseUp() {
    currentDragData = null;
}

// 添加全局事件监听器
document.addEventListener('mousemove', handleGlobalMouseMove);
document.addEventListener('mouseup', handleGlobalMouseUp);

// 4. 添加模块端口
function addPorts(moduleEl, type) {
    const ports = getModulePorts(type);
    
    // 计算模块高度，确保所有端口都能容纳
    const moduleHeight = Math.max(60, 30 + ports.length * 15);
    moduleEl.style.minHeight = `${moduleHeight}px`;
    
    ports.forEach((port, index) => {
        const portEl = document.createElement('div');
        portEl.className = `module-port ${port.direction}`;
        portEl.dataset.portName = port.name;
        portEl.dataset.moduleId = moduleEl.dataset.id;
        portEl.dataset.direction = port.direction;
        
        // 计算端口垂直位置，确保在模块内部居中
        const portTop = (moduleHeight - ports.length * 15) / 2 + index * 15;
        portEl.style.top = `${portTop}px`;
        
        // 添加端口事件
        portEl.addEventListener('mousedown', startConnection);
        
        moduleEl.appendChild(portEl);
        
        // 创建端口名称标签
        const labelEl = document.createElement('div');
        labelEl.className = `port-label ${port.direction}`;
        labelEl.innerText = port.name;
        labelEl.style.top = `${portTop - 6}px`;
        
        moduleEl.appendChild(labelEl);
    });
}

// 5. 获取模块端口定义
const portsMap = {
    uart: [
        { name: 'clk', direction: 'input' },
        { name: 'rst_n', direction: 'input' },
        { name: 'tx', direction: 'output' },
        { name: 'rx', direction: 'input' }
    ],
    gpio: [
        { name: 'clk', direction: 'input' },
        { name: 'rst_n', direction: 'input' },
        { name: 'io_pin', direction: 'output' }
    ],
    fifo: [
        { name: 'clk', direction: 'input' },
        { name: 'rst_n', direction: 'input' },
        { name: 'wr_en', direction: 'input' },
        { name: 'rd_en', direction: 'input' },
        { name: 'data_out', direction: 'output' }
    ],
    clk: [
        { name: 'clk_in', direction: 'input' },
        { name: 'clk_out', direction: 'output' }
    ]
};

function getModulePorts(type) {
    return portsMap[type] || [];
}

// 6. 开始连接
function startConnection(e) {
    e.preventDefault();
    const portEl = e.target;
    const moduleId = parseInt(portEl.dataset.moduleId);
    const portName = portEl.dataset.portName;
    const direction = portEl.dataset.direction;
    
    // 只允许从输出端口开始连接
    if (direction !== 'output') return;
    
    // 创建临时连接线
    currentConnection = {
        startModule: moduleId,
        startPort: portName,
        startX: portEl.getBoundingClientRect().right,
        startY: portEl.getBoundingClientRect().top + portEl.offsetHeight / 2,
        line: document.createElement('div')
    };
    
    currentConnection.line.className = 'connection-line dragging';
    canvas.appendChild(currentConnection.line);
    
    // 监听鼠标移动
    document.addEventListener('mousemove', drawConnection);
    document.addEventListener('mouseup', endConnection);
}

// 7. 绘制连接线
function drawConnection(e) {
    if (!currentConnection) return;
    
    const canvasRect = canvas.getBoundingClientRect();
    const endX = e.clientX - canvasRect.left;
    const endY = e.clientY - canvasRect.top;
    
    const line = currentConnection.line;
    const startX = currentConnection.startX - canvasRect.left;
    const startY = currentConnection.startY - canvasRect.top;
    
    const length = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
    const angle = Math.atan2(endY - startY, endX - startX) * 180 / Math.PI;
    
    line.style.width = length + 'px';
    line.style.left = startX + 'px';
    line.style.top = startY + 'px';
    line.style.transformOrigin = '0 50%';
    line.style.transform = `rotate(${angle}deg)`;
}

// 8. 结束连接
function endConnection(e) {
    if (!currentConnection) return;
    
    // 检查是否连接到输入端口
    const target = e.target;
    if (target.classList.contains('module-port') && target.dataset.direction === 'input') {
        const endModule = parseInt(target.dataset.moduleId);
        const endPort = target.dataset.portName;
        
        // 添加连接
        connections.push({
            startModule: currentConnection.startModule,
            startPort: currentConnection.startPort,
            endModule: endModule,
            endPort: endPort
        });
        
        // 更新代码
        refreshRTL();
        
        // 更新连接线条
        updateConnections();
    }
    
    // 清理临时连接线
    if (currentConnection.line) {
        canvas.removeChild(currentConnection.line);
    }
    currentConnection = null;
    
    // 移除事件监听
    document.removeEventListener('mousemove', drawConnection);
    document.removeEventListener('mouseup', endConnection);
}

// 9. 更新连接线条
function updateConnections() {
    // 清除所有连接线条和圆弧
    document.querySelectorAll('.connection-line').forEach(line => {
        if (!line.classList.contains('dragging')) {
            line.remove();
        }
    });
    
    // 清除所有圆弧
    document.querySelectorAll('.connection-arc').forEach(arc => {
        arc.remove();
    });
    
    // 重新绘制连接线条
    connections.forEach(conn => {
        const startModuleEl = document.querySelector(`.drag-module[data-id="${conn.startModule}"]`);
        const endModuleEl = document.querySelector(`.drag-module[data-id="${conn.endModule}"]`);
        
        if (startModuleEl && endModuleEl) {
            const startPortEl = startModuleEl.querySelector(`.module-port[data-port-name="${conn.startPort}"]`);
            const endPortEl = endModuleEl.querySelector(`.module-port[data-port-name="${conn.endPort}"]`);
            
            if (startPortEl && endPortEl) {
                const canvasRect = canvas.getBoundingClientRect();
                const startX = startPortEl.getBoundingClientRect().right - canvasRect.left;
                const startY = startPortEl.getBoundingClientRect().top + startPortEl.offsetHeight / 2 - canvasRect.top;
                const endX = endPortEl.getBoundingClientRect().left - canvasRect.left;
                const endY = endPortEl.getBoundingClientRect().top + endPortEl.offsetHeight / 2 - canvasRect.top;
                
                // 检查是否需要折弯
                if (needsBending(startModuleEl, endModuleEl, startX, startY, endX, endY)) {
                    // 绘制带折弯的连接线
                    drawBentConnection(startX, startY, endX, endY);
                } else {
                    // 绘制直线连接
                    const line = document.createElement('div');
                    line.className = 'connection-line';
                    
                    const length = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
                    const angle = Math.atan2(endY - startY, endX - startX) * 180 / Math.PI;
                    
                    line.style.width = length + 'px';
                    line.style.left = startX + 'px';
                    line.style.top = startY + 'px';
                    line.style.transformOrigin = '0 50%';
                    line.style.transform = `rotate(${angle}deg)`;
                    
                    canvas.appendChild(line);
                }
            }
        }
    });
}

// 检查是否需要折弯
function needsBending(startModuleEl, endModuleEl, startX, startY, endX, endY) {
    // 简单判断：如果连接线长度超过一定阈值，或者起始点和终点在不同象限，就折弯
    const distance = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
    return distance > 200 || (startX < endX && startY > endY) || (startX > endX && startY < endY);
}

// 绘制带折弯的连接线
function drawBentConnection(startX, startY, endX, endY) {
    // 计算折弯点
    const midX = (startX + endX) / 2;
    const midY = (startY + endY) / 2;
    
    // 为了美观，将折弯点稍微偏移
    const offset = 50;
    const bendX = midX + (startY > endY ? offset : -offset);
    const bendY = midY;
    
    // 绘制第一段线
    const line1 = document.createElement('div');
    line1.className = 'connection-line';
    const length1 = Math.sqrt(Math.pow(bendX - startX, 2) + Math.pow(bendY - startY, 2));
    const angle1 = Math.atan2(bendY - startY, bendX - startX) * 180 / Math.PI;
    line1.style.width = length1 + 'px';
    line1.style.left = startX + 'px';
    line1.style.top = startY + 'px';
    line1.style.transformOrigin = '0 50%';
    line1.style.transform = `rotate(${angle1}deg)`;
    canvas.appendChild(line1);
    
    // 绘制第二段线
    const line2 = document.createElement('div');
    line2.className = 'connection-line';
    const length2 = Math.sqrt(Math.pow(endX - bendX, 2) + Math.pow(endY - bendY, 2));
    const angle2 = Math.atan2(endY - bendY, endX - bendX) * 180 / Math.PI;
    line2.style.width = length2 + 'px';
    line2.style.left = bendX + 'px';
    line2.style.top = bendY + 'px';
    line2.style.transformOrigin = '0 50%';
    line2.style.transform = `rotate(${angle2}deg)`;
    canvas.appendChild(line2);
    
    // 绘制圆弧倒角
    const arc = document.createElement('div');
    arc.className = 'connection-arc';
    arc.style.position = 'absolute';
    arc.style.width = '20px';
    arc.style.height = '20px';
    arc.style.borderRadius = '50%';
    arc.style.border = '2px solid #333';
    arc.style.borderTop = 'none';
    arc.style.borderLeft = 'none';
    arc.style.left = (bendX - 10) + 'px';
    arc.style.top = (bendY - 10) + 'px';
    
    // 根据折弯方向调整圆弧
    if (startX < endX && startY > endY) {
        arc.style.transform = 'rotate(135deg)';
    } else if (startX > endX && startY < endY) {
        arc.style.transform = 'rotate(-45deg)';
    } else if (startX < endX && startY < endY) {
        arc.style.transform = 'rotate(45deg)';
    } else {
        arc.style.transform = 'rotate(-135deg)';
    }
    
    canvas.appendChild(arc);
}

// 10. 自动生成 RTL 代码（核心！）
function refreshRTL() {
    let code = `// ==============================================\n`;
    code += `// 芯片可视化IDE - 自动生成Verilog代码\n`;
    code += `// 可直接用于综合、仿真、流片\n`;
    code += `// ==============================================\n\n`;
    code += 'module chip_top (\n';
    code += '    input  wire clk,\n';
    code += '    input  wire rst_n\n';
    code += '\n);\n\n';

    // 生成模块实例化代码
    placedModules.forEach((m, index) => {
        // 生成模块实例名
        const instName = `${m.type}_inst_${index}`;
        
        if (m.type === 'uart') {
            code += '// UART 串口控制器\n';
            code += `uart ${instName} (\n`;
            code += '    .clk(';
            
            // 检查是否有连接到clk端口
            const clkConnection = connections.find(conn => 
                conn.endModule === m.id && conn.endPort === 'clk'
            );
            
            if (clkConnection) {
                const startModule = placedModules.find(mod => mod.id === clkConnection.startModule);
                const startModuleIndex = placedModules.findIndex(mod => mod.id === clkConnection.startModule);
                const startInstName = `${startModule.type}_inst_${startModuleIndex}`;
                code += `${startInstName}.${clkConnection.startPort}`;
            } else {
                code += 'clk';
            }
            
            code += '),\n';
            code += '    .rst_n(rst_n),\n';
            code += '    .tx(),\n';
            code += '    .rx()\n';
            code += ');\n\n';
        }
        
        if (m.type === 'gpio') {
            code += '// GPIO 通用IO\n';
            code += `gpio ${instName} (\n`;
            code += '    .clk(';
            
            // 检查是否有连接到clk端口
            const clkConnection = connections.find(conn => 
                conn.endModule === m.id && conn.endPort === 'clk'
            );
            
            if (clkConnection) {
                const startModule = placedModules.find(mod => mod.id === clkConnection.startModule);
                const startModuleIndex = placedModules.findIndex(mod => mod.id === clkConnection.startModule);
                const startInstName = `${startModule.type}_inst_${startModuleIndex}`;
                code += `${startInstName}.${clkConnection.startPort}`;
            } else {
                code += 'clk';
            }
            
            code += '),\n';
            code += '    .rst_n(rst_n),\n';
            code += '    .io_pin()\n';
            code += ');\n\n';
        }
        
        if (m.type === 'fifo') {
            code += '// FIFO 数据缓存\n';
            code += `fifo ${instName} (\n`;
            code += '    .clk(';
            
            // 检查是否有连接到clk端口
            const clkConnection = connections.find(conn => 
                conn.endModule === m.id && conn.endPort === 'clk'
            );
            
            if (clkConnection) {
                const startModule = placedModules.find(mod => mod.id === clkConnection.startModule);
                const startModuleIndex = placedModules.findIndex(mod => mod.id === clkConnection.startModule);
                const startInstName = `${startModule.type}_inst_${startModuleIndex}`;
                code += `${startInstName}.${clkConnection.startPort}`;
            } else {
                code += 'clk';
            }
            
            code += '),\n';
            code += '    .rst_n(rst_n),\n';
            code += '    .wr_en(),\n';
            code += '    .rd_en()\n';
            code += ');\n\n';
        }
        
        if (m.type === 'clk') {
            code += '// 时钟发生器\n';
            code += `clk_gen ${instName} (\n`;
            code += '    .clk_in(clk),\n';
            code += '    .clk_out()\n';
            code += ');\n\n';
        }
    });

    code += 'endmodule\n';
    rtlCode.value = code;
}

// 11. 导出代码
function exportCode() {
    const code = rtlCode.value;
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chip_top.v';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// 12. 保存设计
function saveDesign() {
    const design = {
        modules: placedModules,
        connections: connections
    };
    const designJson = JSON.stringify(design, null, 2);
    localStorage.setItem('chipDesign', designJson);
    alert('设计已保存！');
}

// 13. 加载设计
function loadDesign() {
    const designJson = localStorage.getItem('chipDesign');
    if (!designJson) {
        alert('没有找到保存的设计！');
        return;
    }
    
    const design = JSON.parse(designJson);
    
    // 清除现有模块和连接
    canvas.innerHTML = '';
    placedModules = [];
    connections = [];
    nextModuleId = 1;
    
    // 加载模块
    design.modules.forEach(module => {
        const div = document.createElement('div');
        div.className = 'drag-module';
        div.innerText = module.name;
        div.style.left = module.x + 'px';
        div.style.top = module.y + 'px';
        div.dataset.id = module.id;
        div.dataset.type = module.type;
        canvas.appendChild(div);
        
        // 添加端口
        addPorts(div, module.type);
        
        // 保存模块
        placedModules.push(module);
        if (module.id >= nextModuleId) {
            nextModuleId = module.id + 1;
        }
        
        // 启用拖拽
        enableDrag(div);
    });
    
    // 加载连接
    connections = design.connections;
    
    // 更新连接线条
    updateConnections();
    
    // 生成代码
    refreshRTL();
    
    alert('设计已加载！');
}

// 14. 绑定按钮事件
exportBtn.addEventListener('click', exportCode);
saveBtn.addEventListener('click', saveDesign);
loadBtn.addEventListener('click', loadDesign);

// 15. 网格开关功能
const gridBtn = document.getElementById('gridBtn');
let gridEnabled = true;

gridBtn.addEventListener('click', () => {
    gridEnabled = !gridEnabled;
    if (gridEnabled) {
        canvas.style.backgroundImage = 'linear-gradient(#e0e0e0 1px, transparent 1px), linear-gradient(90deg, #e0e0e0 1px, transparent 1px)';
        gridBtn.textContent = '隐藏网格';
    } else {
        canvas.style.backgroundImage = 'none';
        gridBtn.textContent = '显示网格';
    }
});

// 16. 画布平移功能
let isPanning = false;
let lastX, lastY;

canvas.addEventListener('mousedown', (e) => {
    // 只有在空白区域点击时才启用平移
    if (e.target === canvas) {
        isPanning = true;
        lastX = e.clientX;
        lastY = e.clientY;
    }
});

document.addEventListener('mousemove', (e) => {
    if (!isPanning) return;
    
    const deltaX = e.clientX - lastX;
    const deltaY = e.clientY - lastY;
    
    // 移动所有模块
    placedModules.forEach(module => {
        const moduleEl = document.querySelector(`.drag-module[data-id="${module.id}"]`);
        if (moduleEl) {
            const currentX = parseInt(moduleEl.style.left) || 0;
            const currentY = parseInt(moduleEl.style.top) || 0;
            moduleEl.style.left = (currentX + deltaX) + 'px';
            moduleEl.style.top = (currentY + deltaY) + 'px';
            
            // 更新模块位置数据
            module.x = currentX + deltaX;
            module.y = currentY + deltaY;
        }
    });
    
    // 更新连接线条
    updateConnections();
    
    lastX = e.clientX;
    lastY = e.clientY;
});

document.addEventListener('mouseup', () => {
    isPanning = false;
});

// 17. 导入元器件功能
const importBtn = document.getElementById('importBtn');
const importFile = document.getElementById('importFile');
const leftPanel = document.querySelector('.left-panel');

// 点击导入按钮触发文件选择
importBtn.addEventListener('click', () => {
    importFile.click();
});

// 处理文件上传
importFile.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
        const content = event.target.result;
        const modules = parseVerilogModules(content);
        
        if (modules.length > 0) {
            // 添加新模块到元器件库
            modules.forEach(module => {
                addModuleToLibrary(module);
            });
            alert(`成功导入 ${modules.length} 个元器件！`);
        } else {
            alert('未找到有效的模块定义！');
        }
    };
    reader.readAsText(file);
});

// 解析Verilog文件，提取模块信息
function parseVerilogModules(content) {
    const modules = [];
    const moduleRegex = /module\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(([^)]*)\)/g;
    let match;
    
    while ((match = moduleRegex.exec(content)) !== null) {
        const moduleName = match[1];
        const portsStr = match[2];
        const ports = parsePorts(portsStr);
        
        modules.push({
            name: moduleName,
            ports: ports
        });
    }
    
    return modules;
}

// 解析端口信息
function parsePorts(portsStr) {
    const ports = [];
    const portRegex = /(input|output|inout)\s+(wire|reg)?\s*(\[\d+:\d+\])?\s*([a-zA-Z_][a-zA-Z0-9_]*)/g;
    let match;
    
    while ((match = portRegex.exec(portsStr)) !== null) {
        const direction = match[1];
        const portName = match[4];
        
        ports.push({
            name: portName,
            direction: direction
        });
    }
    
    return ports;
}

// 添加模块到元器件库
function addModuleToLibrary(module) {
    // 生成唯一的模块类型ID
    const moduleType = module.name.toLowerCase();
    
    // 检查模块是否已存在
    if (document.querySelector(`.module-item[data-type="${moduleType}"]`)) {
        return; // 模块已存在，跳过
    }
    
    // 创建模块元素
    const moduleEl = document.createElement('div');
    moduleEl.className = 'module-item';
    moduleEl.draggable = true;
    moduleEl.dataset.type = moduleType;
    moduleEl.innerText = module.name;
    
    // 添加拖拽事件
    moduleEl.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('type', moduleType);
        e.dataTransfer.setData('name', module.name);
    });
    
    // 添加到左侧元器件库
    leftPanel.appendChild(moduleEl);
    
    // 更新端口定义
    updateModulePorts(moduleType, module.ports);
}

// 更新模块端口定义
function updateModulePorts(type, ports) {
    // 扩展全局portsMap
    portsMap[type] = ports;
}
